/*-------------------------------------------------------------------
 * Converts from an AXI Stream interface to an AXI-MM write channel
 -------------------------------------------------------------------*/

#include "axis2aximm.h"

void axis2aximm(TLEN_t len, TDATA_t &axis_in, TDATA_t *aximm_wr)
{

    // implement axis_in as AXI Stream interface
    // can be modified, but not removed
    #pragma HLS INTERFACE axis register both depth=256 port=axis_in

    // implement aximm_rd as AXI-MM interface with separate address offset port
    // can be modified, but not removed
    //#pragma HLS INTERFACE m_axi depth=256 port=aximm_wr offset=direct max_read_burst_length=256


    // implement aximm_wr as AXI-MM interface with offset address as register controlled by AXI-Lite
    #pragma HLS INTERFACE m_axi depth=256 port=aximm_wr offset=slave max_read_burst_length=256

	// Use these pragmas to bundle the len & control ports into an AXI-Lite interface
    #pragma HLS INTERFACE s_axilite port=len     bundle=AXILite
    #pragma HLS INTERFACE s_axilite port=return  bundle=AXILite


    // this pragma ensures that AXI-MM and AXIS transactions can occur in parallel - do not remove
    #pragma HLS DATAFLOW


    // HLS stream will be implemented as a FIFO - depth can be modified
	hls::stream<TDATA_t> str2mm_fifo;
    #pragma HLS STREAM variable=str2mm_fifo depth=256 dim=1


    // read from AXI stream and write to FIFO
    loop0: for (int i=0; i < len; i++) { 
    #pragma HLS LOOP_TRIPCOUNT avg=256
    #pragma HLS PIPELINE II=1
		str2mm_fifo << axis_in;
	}


    // Read from the FIFO, then write out to the AXI-MM interface
    // must use the PIPELINE pragma to get burst writes
	loop1: for (int i=0; i < len; i++) {
    #pragma HLS LOOP_TRIPCOUNT avg=256
    #pragma HLS PIPELINE II=1
        str2mm_fifo >> aximm_wr[i];            // read from FIFO
		cout << aximm_wr[i] << endl;           // debug only
	}

}


