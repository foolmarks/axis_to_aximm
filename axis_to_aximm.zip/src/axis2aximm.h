#ifndef _AXICONV_DEFS_
#define _AXICONV_DEFS_

#include <stdio.h>
#include <iostream>
#include <string.h>
#include <hls_stream.h>
#include "ap_int.h"

using namespace std;


/*-------------------------------------------
  TYPES & CONSTANTS DEFINITIONS
-------------------------------------------*/

// data width for AXI-MM & AXIS is 32bits, can be changed as required
typedef ap_uint<32>  TDATA_t;


// transfer length type
typedef ap_uint<32>  TLEN_t;



/*-------------------------------------------
  FUNCTION PROTOTYPES
-------------------------------------------*/
void axis2aximm(TLEN_t len, TDATA_t &axis_in, TDATA_t *aximm_wr);



#endif
