/*-------------------------------------------------------------------
 * testbench for AXI-MM master interface to AXI Stream interface
 -------------------------------------------------------------------*/

#include "../src/axis2aximm.h"


int main(void)
{
	TDATA_t din;
	TDATA_t dout[256];
	TLEN_t len;


	len = 16;
	din = 34;
    axis2aximm(len, din, dout);

	len = 8;
	din = 28;
    axis2aximm(len, din, dout);


	return 0;

}
